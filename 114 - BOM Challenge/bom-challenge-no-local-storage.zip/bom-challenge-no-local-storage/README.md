# BOM Challenge (NO local storage)

A Pen created on CodePen.io. Original URL: [https://codepen.io/zohayrslileh/pen/GRxBazQ](https://codepen.io/zohayrslileh/pen/GRxBazQ).

